# Cancer as a Game - Simulator (v0.6 UI)
# Adds: Streamlit UI for user interaction

import streamlit as st
import random
import numpy as np
import matplotlib.pyplot as plt

st.title("🧬 Cancer Game Simulator - Chaos & Evolution")

# User input sliders
aggressive = st.slider("Initial Aggressive Cells", 0, 100, 30)
stealth = st.slider("Initial Stealth Cells", 0, 100, 30)
immune = st.slider("Initial Immune Cells", 0, 100, 40)
chemo_strength = st.slider("Chemo Strength", 0.0, 10.0, 4.0)
immune_boost = st.slider("Immune Boost", 0.0, 10.0, 2.0)
drug_decay_rate = st.slider("Drug Decay Rate", 0.5, 1.0, 0.85)
noise_level = st.slider("Chaos Level (Gaussian Noise)", 0.0, 2.0, 0.5)
rounds = st.slider("Simulation Rounds", 10, 200, 50)

# Run simulation
initial_pop = {'aggressive': aggressive, 'stealth': stealth, 'immune': immune}

@st.cache_data
def run_sim(initial_pop, chemo_strength, immune_boost, drug_decay_rate, noise_level, rounds):
    populations = initial_pop.copy()
    drug_concentration = 0
    payoff_matrix = {
        'aggressive': {'aggressive': -2, 'stealth': 1, 'immune': -5},
        'stealth':    {'aggressive': 2,  'stealth': 0, 'immune': -1},
        'immune':     {'aggressive': 4,  'stealth': 2, 'immune': -3}
    }
    history = {k: [] for k in populations.keys()}
    history['total'] = []
    history['fitness'] = []

    for _ in range(rounds):
        total_cells = sum(populations.values())
        frequencies = {k: populations[k] / total_cells for k in populations}

        if frequencies['aggressive'] > 0.4:
            drug_concentration = 1.0
        else:
            drug_concentration *= drug_decay_rate

        fitness = {}
        total_fitness = 0
        for i in populations:
            f = sum(payoff_matrix[i][j] * frequencies[j] for j in populations)
            if i == 'aggressive': f -= chemo_strength * drug_concentration
            if i == 'immune': f += immune_boost * drug_concentration
            f += np.random.normal(0, noise_level)
            fitness[i] = f
            total_fitness += populations[i] * f / total_cells

        new_pop = {}
        for i in populations:
            delta = populations[i] * (fitness[i] - total_fitness) / total_cells
            new_pop[i] = max(0, round(populations[i] + delta))

        if drug_concentration > 0.5:
            if random.random() < 0.05:
                new_pop['stealth'] += 1
                new_pop['aggressive'] = max(0, new_pop['aggressive'] - 1)
            if random.random() < 0.05:
                new_pop['aggressive'] += 1
                new_pop['stealth'] = max(0, new_pop['stealth'] - 1)

        populations = new_pop
        for k in populations:
            history[k].append(populations[k])
        history['total'].append(sum(populations.values()))
        history['fitness'].append(total_fitness)

    return history

hist = run_sim(initial_pop, chemo_strength, immune_boost, drug_decay_rate, noise_level, rounds)

# Plot outputs
st.subheader("📈 Cell Population Dynamics")
fig1, ax1 = plt.subplots()
for k in ['aggressive', 'stealth', 'immune']:
    ax1.plot(hist[k], label=k)
ax1.set_xlabel("Rounds")
ax1.set_ylabel("Population Size")
ax1.legend()
ax1.grid(True)
st.pyplot(fig1)

st.subheader("📉 System Fitness Over Time")
fig2, ax2 = plt.subplots()
ax2.plot(hist['fitness'], label='Avg Fitness', color='purple')
ax2.set_xlabel("Rounds")
ax2.set_ylabel("Population Fitness")
ax2.grid(True)
ax2.legend()
st.pyplot(fig2)
